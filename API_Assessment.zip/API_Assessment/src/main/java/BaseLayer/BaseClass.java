package BaseLayer;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class BaseClass {
	public String getproperty(String key)
	{
		Properties p= new Properties();
		FileInputStream fs;
		try
		{
			fs=new FileInputStream("\\C:\\Users\\user\\eclipse-workspace\\API_Assessment\\src\\main\\java\\ConfigLayer\\Config.properties");
			
		//	fs=new FileInputStream(System.getProperty("user.dir")+"\\C:\\Users\\user\\eclipse-workspace\\API_Assessment\\src\\main\\java\\ConfigLayer\\Config.properties");
			p.load(fs);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return p.getProperty(key);
	}
	public RequestSpecification setup(String keys)
	{
		RestAssured.baseURI=getproperty(keys);
		return RestAssured.given().filter(RequestLoggingFilter.logRequestTo(logs("RequestLog","reqlog"))).filter(ResponseLoggingFilter.logResponseTo(logs("ResponseLog","resplog"))).contentType(ContentType.JSON);
		
	}
	public PrintStream logs(String foldername , String filename)
	{
		String date= new SimpleDateFormat("ddMMyy_HHmmss").format(new Date());
		String path=System.getProperty("user.dir")+"//"+foldername+filename+date+".txt";
		try
		{
			return new PrintStream(new FileOutputStream(path));
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		return null;
	}
}



