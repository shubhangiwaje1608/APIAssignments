package UtilsLayer;

import PojoLayer.Pojoclass;

public class TestData {
public String adddata(int id,String email,String firstname,String lastname,String avatar)
{
	Pojoclass pr=new Pojoclass();
	pr.setId(id);
	pr.setEmail(email);
	pr.setFirst_name(firstname);
	pr.setLast_name(lastname);
	pr.setAvatar(avatar);

return Utilclass.convertdata(pr);
}

}
