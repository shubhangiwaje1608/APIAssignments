package UtilsLayer;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Utilclass {
	public static String convertdata(Object obj)
	{
		ObjectMapper mapper=new ObjectMapper();
		String json= null;
		try
		{
			json=mapper.writeValueAsString(obj);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return json;
	}

}
