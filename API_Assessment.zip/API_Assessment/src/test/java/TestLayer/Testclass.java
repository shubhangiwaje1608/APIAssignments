package TestLayer;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import BaseLayer.BaseClass;
import UtilsLayer.TestData;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Testclass extends BaseClass {
	private 	BaseClass b;
	private 	Response rs;
	private int idd;
	private TestData t;
	@BeforeTest
	public void initialization() {
		b=new BaseClass();
		b.setup("baseUri");
	}
	
	@Test
	public void retrivedata()
	{
		
		 rs=b.setup("baseUri").get();
		String data=rs.getBody().asString();
		JsonPath j=new JsonPath(data);
		j.getString("first_name");
		j.getString("email");
		j.getString("id");
		int len=data.length();
		for(int i=0;i<len;i++)
		{
			System.out.println(j.getInt("id")+j.getString("email")+j.getString("first_name")+j.getString("last_name")+j.getString("avatar"));
		}
		
	int responsetime=	rs.statusCode();
	System.out.println(responsetime);
	
	
	}
	@Test
	public void createnewuser()
	{
		RequestSpecification  r=b.setup("baseURI");
		 t= new TestData();
		
	String a=	t.adddata(124, "abc@gmail.com", "kavita", "patil", "https://reqres.in/img/faces/1-image.jpg");
	
	Response resp=r.body(a).post();
	String data=resp.getBody().asString();
JsonPath j=new JsonPath(data);
idd=j.getInt("id");
	int responsecode=	resp.statusCode();
	System.out.println(responsecode);
//	assert.assertTrue(true, "data");
	System.out.println(j.getInt("id")+j.getString("email")+j.getString("first_name")+j.getString("last_name")+j.getString("avatar"));
	
	}
	@Test
	public void updatedetails()
	{
		RequestSpecification  r=b.setup("putURI");
		
		
		String a=	t.adddata(124, "xyz@gmail.com", "abhilasha", "saste", "https://reqres.in/img/faces/1-image.jpg");
		
		Response resp=r.body(a).put();
		String data=resp.getBody().asString();
		JsonPath j=new JsonPath(data);
		int responsecode=	resp.statusCode();
		System.out.println(responsecode);
		System.out.println(j.getInt("id")+j.getString("email")+j.getString("first_name")+j.getString("last_name")+j.getString("avatar"));
		
		
	}

}
